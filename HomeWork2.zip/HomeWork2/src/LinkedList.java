import java.util.AbstractList;
import java.util.Arrays;
public class LinkedList<E> extends AbstractList<E> {

    private int default_capacity = 10;
    private Object[] elementData;
    private int size = 0;

    public LinkedList() {
        elementData = new Object[default_capacity];
    }
    public LinkedList(int capacity){
        elementData = new Object[capacity];
    }

    @Override
    public E get(int index) {
        if (index >= size || index < 0 ){
            throw new IndexOutOfBoundsException("Index" + index + "out of bounds for length " + size);
        }
        return (E) elementData[index];
    }

    @Override
    public int size() {
        return size;
    }

    public void ensureCapacity(){
        int newSize = elementData.length + (elementData.length/2);
        elementData = Arrays.copyOf(elementData, newSize);
    }

    @Override
    public void add(int index, E element){
        if (index > size || index < 0) {
            throw new  IndexOutOfBoundsException("Index" + index + "out of bounds for length " + size);
        }
        if (index == elementData.length){
            ensureCapacity();
        }
        for (int i = size - 1; i >= index ; i--) {
            elementData[i + 1] = elementData[i];
        }
        elementData[index] = element;
        size++;
    }
    @Override
    public E remove(int index) {
        if (index >= size || index < 0) {
            throw new IndexOutOfBoundsException("Index" + index + "out of bounds for length " + size);
        }
        Object temp = elementData[index];
        for (int i = index; i < size; i++){
            elementData[i] = elementData[i + 1];
        }
        size--;
        return (E) temp;
    }
}


